//================================//
// Main
//================================//
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['62']
//================================//
// Sticker
//================================//
global.packname = "Sticker By RizxVelz"
global.author = "RizxvelzOfficial"
//================================//
// Global Mess
//================================//
global.menuMode = global.menuMode || 'nobutton';
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*',
 group: '*This feature is for groups only*'
}