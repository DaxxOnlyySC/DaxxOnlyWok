//========HELO FRIEND========//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283857703978"] 
global.namabot = 'the shadow v4'
//======================
global.mess = { 
owner: '*waduhh!, lu bukan owner gw bg*',
premium: '*anda bukan user premium*',
succes: '*done bang*'
}
//======================